﻿namespace ActiveUp.Net.Mail
{
    public class CommandOptions
    {
        public bool IsPlusCmdAllowed { get; set; }

        public CommandOptions()
        {
            IsPlusCmdAllowed = true;
        }
    }
}
